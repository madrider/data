--Stored Procedure
use NORTHWND

select * from Products

go
create procedure usp_displayproducts
as
begin
select ProductId,ProductName,UnitPrice
from Products
end
go

exec usp_displayproducts

execute usp_displayproducts

usp_displayproducts

go
create proc usp_displayprodbycategory(@catid int)
as
begin 
select * from Products where CategoryID=@catid
end
go

exec usp_displayprodbycategory 6

go
create proc usp_getproductcount(@catid int,@count int out)
as
begin 
select @count=count(*) from Products where CategoryID=@catid
end
go

declare @count int
execute usp_getproductcount 6,@count out
select @count

sp_help usp_getproductcount

sp_helptext usp_getproductcount

drop proc usp_getproductcount
go
create proc usp_getproductcount(@catid int,@count int out)
with ENCRYPTION
as
begin 
select @count=count(*) from Products where CategoryID=@catid
end
go