create table Category
(
	categoryid int primary key,
	categoryname varchar(40)
)

go
create proc usp_addcategory(@id int,@name varchar(40))
as
begin
insert into Category values(@id,@name)
end
go

exec usp_addcategory 101,'Sales'
exec usp_addcategory 102,'account'

select * from Category
go
CREATE PROC usp_InsertCategory
(
          @CatID	INT,
          @CatName	VARCHAR(40)
)
ASBEGIN
          IF(@CatID IS NULL OR @CatID < 0)
          BEGIN
                    RAISERROR('Category ID cannot be null or negative', 1, 1)
          END
          ELSE
          BEGIN
                    IF EXISTS (SELECT CategoryID FROM Category WHERE CategoryID = @CatID)
                    BEGIN
                              RAISERROR('Category ID already exists', 1, 1)                    END
                    ELSE                    BEGIN
                              INSERT INTO Category
                              (CategoryID, CategoryName)
                              VALUES
                              (@CatID, @CatName)
                    END
          END	
END

exec usp_InsertCategory null,'IT'


CREATE TABLE Product
(
ProductID INT PRIMARY KEY,
ProductName VARCHAR(30),
UnitPrice   MONEY,
Quantity INT,
CategoryID INT FOREIGN KEY REFERENCES Category(CategoryID)
)

go
CREATE PROC usp_InsertProduct
(
          @ProdID	INT,
          @ProdName VARCHAR(20),
          @Price MONEY,
          @Qty INT,
          @CatID INT
)
ASBEGIN
          IF(@ProdID IS NULL OR @ProdID < 0)
          BEGIN
                    RAISERROR('Product ID cannot be null or negative', 1, 1)
          END
          ELSE
          BEGIN
                    IF EXISTS (SELECT ProductName FROM Product WHERE ProductID = @ProdID)
                    BEGIN
                              RAISERROR('Product ID already exists', 1, 1)                    END
                    ELSE                    BEGIN
                              IF EXISTS (SELECT CategoryName FROM Category WHERE CategoryID = @CatID OR @CatID IS NULL)
                              BEGIN
                                        IF (@Price <= 0 OR @Qty <=0)
                                        BEGIN
                                                  RAISERROR('Unit Price or Quantity cannot be negative or zero', 1, 1)
                                        END
                                        ELSE
                                        BEGIN
                                                  INSERT INTO Product
                                                  (ProductID, ProductName, UnitPrice, Quantity, CategoryID)
                                                  VALUES
                                                  (@ProdID, @ProdName, @Price, @Qty, @CatID)
                                        END
                              END
                              ELSE                              BEGIN
                                        RAISERROR('Category ID does not exists', 1, 1)
                              END
                    END
          END	
END

exec usp_InsertProduct 112,'ABCii',9,99,109
